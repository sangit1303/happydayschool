document.addEventListener('DOMContentLoaded', () => {
    const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
    const navLinks = document.querySelector('.nav-links');

    if (mobileMenuBtn) {
        mobileMenuBtn.addEventListener('click', () => {
            navLinks.classList.toggle('active');

            // Change icon
            const icon = mobileMenuBtn.querySelector('i');
            if (navLinks.classList.contains('active')) {
                icon.classList.remove('fa-bars');
                icon.classList.add('fa-times');
            } else {
                icon.classList.remove('fa-times');
                icon.classList.add('fa-bars');
            }
        });
    }

    // Close menu when clicking a link
    document.querySelectorAll('.nav-links a').forEach(link => {
        link.addEventListener('click', () => {
            if (window.innerWidth <= 768) {
                navLinks.classList.remove('active');
                const icon = mobileMenuBtn.querySelector('i');
                icon.classList.remove('fa-times');
                icon.classList.add('fa-bars');
            }
        });
    });

    // Smooth scroll for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;

            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                targetElement.scrollIntoView({
                    behavior: 'smooth'
                });
            }
        });
    });

    // WhatsApp Contact Form Handler
    const contactForm = document.getElementById('contact-form');
    if (contactForm) {
        contactForm.addEventListener('submit', function (e) {
            e.preventDefault();
            console.log("Form submitted");

            const name = document.getElementById('contact-name').value;
            const email = document.getElementById('contact-email').value;
            const phone = document.getElementById('contact-phone').value;
            const message = document.getElementById('contact-message').value;

            // Added country code 91
            const whatsappNumber = "919500046846";

            // Construct the message
            let whatsappMessage = `*New Enquiry from Website* %0a%0a`;
            whatsappMessage += `*Name:* ${name}%0a`;
            whatsappMessage += `*Email:* ${email}%0a`;
            whatsappMessage += `*Phone:* ${phone}%0a`;
            whatsappMessage += `*Message:* ${message}`;

            // Create the WhatsApp URL
            const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${whatsappMessage}`;
            console.log("Redirecting to:", whatsappUrl);

            // Open in new tab
            window.open(whatsappUrl, '_blank');
        });
    }

    // Teacher Training Application Form Handler
    const applicationForm = document.getElementById('application-form');
    if (applicationForm) {
        applicationForm.addEventListener('submit', function (e) {
            e.preventDefault();
            console.log("Application Form submitted");

            const name = document.getElementById('app-name').value;
            const email = document.getElementById('app-email').value;
            const phone = document.getElementById('app-phone').value;
            const qualification = document.getElementById('app-qualification').value;

            // Added country code 91
            const whatsappNumber = "919500046846";

            // Construct the message
            let whatsappMessage = `*New Teacher Training Application* %0a%0a`;
            whatsappMessage += `*Name:* ${name}%0a`;
            whatsappMessage += `*Email:* ${email}%0a`;
            whatsappMessage += `*Phone:* ${phone}%0a`;
            whatsappMessage += `*Qualification:* ${qualification}`;

            // Create the WhatsApp URL
            const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${whatsappMessage}`;
            console.log("Redirecting to:", whatsappUrl);

            // Open in new tab
            window.open(whatsappUrl, '_blank');
        });
    }

    // Enrollment Form Handler
    const enrollmentForm = document.getElementById('enrollment-form');
    if (enrollmentForm) {
        enrollmentForm.addEventListener('submit', function (e) {
            e.preventDefault();
            console.log("Enrollment Form submitted");

            // Get form values - Note: We need to add IDs to the inputs in enroll.html first or select by name/order
            // Let's assume we will update enroll.html to have IDs, or use querySelector
            const inputs = enrollmentForm.querySelectorAll('input, select');
            const parentName = inputs[0].value;
            const childName = inputs[1].value;
            const childAge = inputs[2].value;
            const phone = inputs[3].value;
            const program = inputs[4].value;

            // Added country code 91
            const whatsappNumber = "919500046846";

            // Construct the message
            let whatsappMessage = `*New Enrollment Enquiry* %0a%0a`;
            whatsappMessage += `*Parent Name:* ${parentName}%0a`;
            whatsappMessage += `*Child Name:* ${childName}%0a`;
            whatsappMessage += `*Child Age:* ${childAge}%0a`;
            whatsappMessage += `*Phone:* ${phone}%0a`;
            whatsappMessage += `*Program:* ${program}`;

            // Create the WhatsApp URL
            const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${whatsappMessage}`;

            // Open in new tab
            window.open(whatsappUrl, '_blank');
        });
    }
});
